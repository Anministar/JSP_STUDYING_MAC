new Swiper('header>.inner>.gnb-top>.header-banner>.swiper',{
  direction:'vertical',
  autoplay:true, //3000m/s 기본
  loop:true
});